import React from 'react'
import BookingAdList from '../components/BookingAdList'

const BookingListings = () => {
  return (
    <div>
      <BookingAdList/>
    </div>
  )
}

export default BookingListings
